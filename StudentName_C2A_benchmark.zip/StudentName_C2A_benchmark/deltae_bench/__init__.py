"""ΔE-Bench — a benchmark for PREDICTIVE metacognition in LLMs.

Protocol: Predict–Answer–Verify (PAV)
Domains:  D1 familiar-verifiable / D2 novel-verifiable (procedurally generated)
          / D3 unknowable (procedurally generated pseudo-facts)
Metrics:  ΔE, ECE, AUC, d′, Metacognitive Gain (MG)

Zero third-party dependencies (standard library only) for reproducibility.
"""

__version__ = "0.1.0"
