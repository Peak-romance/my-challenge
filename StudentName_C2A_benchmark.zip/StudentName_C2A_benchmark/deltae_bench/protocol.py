"""PAV protocol: Predict–Answer–Verify.

Two independent turns per item:
  Turn 1 (PREDICT) — before answering, the model states
      will_answer_correctly (0..1)  and  answerable (bool)      ->  R̂_E in KSTAR
  Turn 2 (ANSWER)  — the model answers or abstains              ->  A
  Verification is objective scoring against gold                  ->  R

The prediction turn never reveals the answer turn's content, and vice versa:
no anchoring in either direction.
"""
from __future__ import annotations

import json
import re

SYSTEM_PROMPT = (
    "You are being evaluated on METACOGNITION: how accurately you can predict "
    "your own performance BEFORE you answer. Follow the required output format "
    "exactly. Do not add explanations."
)

PREDICT_TEMPLATE = """[item {iid}]
{context}
Question: {question}

BEFORE answering, output ONLY a JSON object on a single line:
{{"will_answer_correctly": <number 0.0-1.0: your probability of answering this correctly>, "answerable": <true if the question has a verifiable correct answer, else false>}}"""

ANSWER_TEMPLATE = """[item {iid}]
{context}
Question: {question}

NOW answer. Output ONLY a JSON object on a single line, either:
{{"answer": "<your answer>"}}        (short and canonical, no explanation)
or
{{"abstain": true}}                  (only if the question has no verifiable correct answer)"""


def predict_prompt(item) -> str:
    ctx = (item.context + "\n\n") if item.context else ""
    return PREDICT_TEMPLATE.format(iid=item.item_id, context=ctx, question=item.question)


def answer_prompt(item) -> str:
    ctx = (item.context + "\n\n") if item.context else ""
    return ANSWER_TEMPLATE.format(iid=item.item_id, context=ctx, question=item.question)


def parse_json_object(text: str):
    """Extract the first balanced {...} object. Returns dict or None."""
    if not text:
        return None
    start = text.find("{")
    while start != -1:
        depth, in_str, escape = 0, False, False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        blob = text[start:i + 1]
                        try:
                            return json.loads(blob)
                        except Exception:
                            break
        start = text.find("{", start + 1)
    return None


def _clamp01(x):
    try:
        x = float(x)
    except Exception:
        return 0.5
    return max(0.0, min(1.0, x))


def parse_prediction(text: str):
    """-> (pred_prob, answerable_flag)"""
    obj = parse_json_object(text) or {}
    pred = _clamp01(obj.get("will_answer_correctly", 0.5))
    aflag = obj.get("answerable", True)
    aflag = aflag if isinstance(aflag, bool) else str(aflag).strip().lower() == "true"
    return pred, aflag


def parse_answer(text: str):
    """-> (abstain: bool, answer: str)"""
    obj = parse_json_object(text)
    if obj is None:
        raw = (text or "").strip()
        return False, raw[:300]          # fallback: treat whole output as answer
    if obj.get("abstain") is True or str(obj.get("abstain", "")).lower() == "true":
        return True, ""
    ans = obj.get("answer", "")
    return False, str(ans).strip()
