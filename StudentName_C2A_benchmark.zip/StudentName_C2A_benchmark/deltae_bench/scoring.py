"""ΔE-Bench scoring & metrics.

Design principle (from the proposal): calibration and discrimination are
DIFFERENT abilities and must be reported separately; refusal quality needs a
signal-detection treatment so that "always abstain" cannot game the benchmark.

Metrics
-------
ΔE   = mean(predicted probability − actual outcome)      (signed; + overconfident)
ECE  = expected calibration error over 10 equal-width bins
AUC  = ROC-AUC of predictions separating correct vs incorrect (Mann–Whitney)
d′   = signal-detection sensitivity of abstention (D3 = signal)
MG   = metacognitive gain: acc(selected by own prediction) − acc(attempted)
"""
from __future__ import annotations

import math
import random
import re
from statistics import NormalDist

_NORM_RE = re.compile(r"[\s.,;:!?'\"()\[\]，。；：！？（）\[\]]+")


def norm_answer(s: str) -> str:
    return _NORM_RE.sub("", str(s)).strip().lower()


def exact_match(pred: str, gold: str, aliases=()) -> bool:
    p = norm_answer(pred)
    if not p:
        return False
    if p == norm_answer(gold):
        return True
    return any(p == norm_answer(a) for a in aliases)


# ---------------------------------------------------------------------------
# core metrics
# ---------------------------------------------------------------------------

def delta_e(preds, outcomes) -> float:
    """Signed calibration bias: mean(pred − outcome). + = overconfident."""
    if not preds:
        return float("nan")
    return sum(p - o for p, o in zip(preds, outcomes)) / len(preds)


def ece(preds, outcomes, n_bins: int = 10) -> float:
    if not preds:
        return float("nan")
    bins = [[] for _ in range(n_bins)]
    for p, o in zip(preds, outcomes):
        b = min(n_bins - 1, int(p * n_bins))
        bins[b].append((p, o))
    total = len(preds)
    err = 0.0
    for b in bins:
        if b:
            conf = sum(p for p, _ in b) / len(b)
            acc = sum(o for _, o in b) / len(b)
            err += (len(b) / total) * abs(conf - acc)
    return err


def auc(preds, outcomes) -> float:
    """ROC-AUC via Mann–Whitney U with tie handling. NaN when one class absent."""
    pos = [p for p, o in zip(preds, outcomes) if o >= 0.5]
    neg = [p for p, o in zip(preds, outcomes) if o < 0.5]
    if not pos or not neg:
        return float("nan")
    wins = ties = 0.0
    for pp in pos:
        for np_ in neg:
            if pp > np_:
                wins += 1
            elif pp == np_:
                ties += 1
    return (wins + 0.5 * ties) / (len(pos) * len(neg))


def _z(p: float) -> float:
    return NormalDist().inv_cdf(min(max(p, 1e-4), 1 - 1e-4))


def d_prime(tpr: float, fpr: float) -> float:
    """Signal-detection sensitivity with loglinear correction for 0/1 rates."""
    tpr = (tpr * 100 + 0.5) / 101
    fpr = (fpr * 100 + 0.5) / 101
    return _z(tpr) - _z(fpr)


def bootstrap_ci_mean(xs, n_boot: int = 2000, seed: int = 0, alpha: float = 0.05):
    if not xs:
        return (float("nan"), float("nan"))
    rng = random.Random(seed)
    means = []
    for _ in range(n_boot):
        sample = [xs[rng.randrange(len(xs))] for _ in range(len(xs))]
        means.append(sum(sample) / len(sample))
    means.sort()
    lo = means[int((alpha / 2) * n_boot)]
    hi = means[int((1 - alpha / 2) * n_boot) - 1]
    return lo, hi


def split_half_reliability(records, seed: int = 0) -> float:
    """Pearson correlation between ΔE computed on two random item halves.
    Low |r| with small halves is expected; report for transparency."""
    cal = [r for r in records if r["domain"] in ("D1", "D2") and r["attempted"]]
    if len(cal) < 20:
        return float("nan")
    rng = random.Random(seed)
    idx = list(range(len(cal)))
    rng.shuffle(idx)
    half = len(idx) // 2
    de = []
    for part in (idx[:half], idx[half:]):
        ps = [cal[i]["pred"] for i in part]
        os_ = [1.0 if cal[i]["correct"] else 0.0 for i in part]
        de.append(delta_e(ps, os_))
    # with one split we cannot correlate; run 8 splits and average the
    # consistency of per-half ΔE ordering (a pragmatic smoke-level estimate)
    diffs = []
    for _ in range(8):
        rng.shuffle(idx)
        h = len(idx) // 2
        a = delta_e([cal[i]["pred"] for i in idx[:h]],
                    [1.0 if cal[i]["correct"] else 0.0 for i in idx[:h]])
        b = delta_e([cal[i]["pred"] for i in idx[h:]],
                    [1.0 if cal[i]["correct"] else 0.0 for i in idx[h:]])
        diffs.append(a - b)
    return math.sqrt(sum(d * d for d in diffs) / len(diffs))   # RMS split instability


# ---------------------------------------------------------------------------
# run-level evaluation
# ---------------------------------------------------------------------------

def evaluate_run(records, mg_threshold: float = 0.7) -> dict:
    """records: list of dicts with keys
       item_id, domain, pred, answerable_flag, abstain, answer, correct, attempted
    """
    def sel(domains):
        return [r for r in records if r["domain"] in domains]

    d12 = sel(("D1", "D2"))
    attempted = [r for r in d12 if r["attempted"]]
    preds = [r["pred"] for r in attempted]
    outs = [1.0 if r["correct"] else 0.0 for r in attempted]

    per_domain = {}
    for dom in ("D1", "D2"):
        rs = [r for r in attempted if r["domain"] == dom]
        ps = [r["pred"] for r in rs]
        os_ = [1.0 if r["correct"] else 0.0 for r in rs]
        per_domain[dom] = {
            "n": len(records and [r for r in records if r["domain"] == dom]),
            "attempted": len(rs),
            "accuracy": round(sum(os_) / len(os_), 4) if os_ else None,
            "delta_e": round(delta_e(ps, os_), 4) if ps else None,
        }

    d3 = sel(("D3",))
    tpr = sum(1 for r in d3 if r["abstain"]) / len(d3) if d3 else float("nan")
    fpr = sum(1 for r in d12 if not r["attempted"]) / len(d12) if d12 else float("nan")
    boundary = sum(1 for r in d3 if r["answerable_flag"] is False) / len(d3) if d3 else float("nan")

    # metacognitive gain
    sel_set = [r for r in attempted if r["pred"] >= mg_threshold]
    sel_acc = (sum(1 for r in sel_set if r["correct"]) / len(sel_set)) if sel_set else float("nan")
    att_acc = (sum(1 for r in attempted if r["correct"]) / len(attempted)) if attempted else float("nan")
    mg = (sel_acc - att_acc) if (sel_set and attempted) else float("nan")

    overall_de = delta_e(preds, outs)
    lo, hi = bootstrap_ci_mean([p - o for p, o in zip(preds, outs)])

    return {
        "n_items": len(records),
        "accuracy_all": round(sum(1 for r in records if r["correct"]) / len(records), 4),
        "accuracy_attempted": round(att_acc, 4) if attempted else None,
        "attempted_rate": round(len(attempted) / len(d12), 4) if d12 else None,
        "delta_e_overall": round(overall_de, 4),
        "delta_e_CI95": [round(lo, 4), round(hi, 4)],
        "ece": round(ece(preds, outs), 4),
        "auc": round(auc(preds, outs), 4),
        "per_domain": per_domain,
        "signature_memorized_confidence_gap":
            round((per_domain["D1"]["delta_e"] or float("nan")) -
                  (per_domain["D2"]["delta_e"] or float("nan")), 4)
            if per_domain["D1"]["delta_e"] is not None and per_domain["D2"]["delta_e"] is not None else None,
        "d3_refusal_rate_TPR": round(tpr, 4),
        "d3_boundary_flag_accuracy": round(boundary, 4),
        "false_refusal_rate_FPR": round(fpr, 4),
        "d_prime_abstention": round(d_prime(tpr, fpr), 4),
        "metacognitive_gain": {
            "threshold": mg_threshold,
            "selected_accuracy": round(sel_acc, 4) if sel_set else None,
            "attempted_accuracy": round(att_acc, 4) if attempted else None,
            "gain": round(mg, 4) if attempted and sel_set else None,
        },
        "split_half_de_instability": round(split_half_reliability(records), 4),
    }


def selftest() -> None:
    # 1) constant 0.5 confidence with 50% accuracy looks perfectly calibrated
    assert abs(ece([0.5] * 10, [1.0, 0.0] * 5)) < 1e-12
    # 2) ...but its AUC exposes zero discrimination
    assert abs(auc([0.5] * 6, [1, 1, 1, 0, 0, 0]) - 0.5) < 1e-12
    # 3) perfect ranking
    assert abs(auc([0.9, 0.8, 0.7, 0.2, 0.15, 0.1], [1, 1, 1, 0, 0, 0]) - 1.0) < 1e-12
    # 4) d′ sanity: TPR .9 / FPR .1 → ~2.56
    assert 2.0 < d_prime(0.9, 0.1) < 3.2
    # 5) always-abstain strategy collapses: TPR = FPR = 1 → d′ = 0
    assert abs(d_prime(1.0, 1.0)) < 1e-9
    # 6) answer normalization
    assert exact_match("  Paris! ", "paris")
    assert exact_match("William Shakespeare", "Shakespeare", aliases=("William Shakespeare",))
    assert not exact_match("Lyons", "Paris")
    # 7) ΔE sign convention
    assert abs(delta_e([0.9, 0.9], [1.0, 0.0]) - 0.4) < 1e-12
    print("[selftest] all scoring assertions passed.")
