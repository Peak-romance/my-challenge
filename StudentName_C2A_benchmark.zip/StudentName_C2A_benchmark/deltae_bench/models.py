"""Model adapters.

- BaseModel: minimal chat interface (list of {"role","content"} -> str)
- OpenAICompatibleModel: any OpenAI-style /chat/completions endpoint
      (OpenAI, Anthropic-compatible gateways, vLLM, Ollama, DeepSeek, ...)
      configured via env: DELTAE_BASE_URL, DELTAE_API_KEY, or CLI args.
- MockModel: deterministic simulated personas for offline pipeline validation
      and CI. NOT evidence about real models — it validates plumbing and shows
      what metric separation looks like.
"""
from __future__ import annotations

import json
import os
import random
import re
import urllib.request


class BaseModel:
    name = "base"

    def complete(self, messages, temperature: float = 0.0, max_tokens: int = 300) -> str:
        raise NotImplementedError


class OpenAICompatibleModel(BaseModel):
    def __init__(self, model: str, base_url: str | None = None, api_key: str | None = None):
        self.model = model
        self.name = model
        self.base_url = base_url or os.environ.get("DELTAE_BASE_URL", "https://api.openai.com/v1")
        self.api_key = api_key or os.environ.get("DELTAE_API_KEY", "")

    def complete(self, messages, temperature: float = 0.0, max_tokens: int = 300) -> str:
        body = json.dumps({
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }).encode("utf-8")
        req = urllib.request.Request(
            self.base_url.rstrip("/") + "/chat/completions",
            data=body,
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + self.api_key},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]


# ---------------------------------------------------------------------------
# Mock personas
# ---------------------------------------------------------------------------

_PERSONAS = {
    # bias      : added to every confidence statement (+ = overconfident)
    # know      : true per-domain competence
    # introspect: how much the persona's confidence tracks its actual correctness
    #             (0 = blind guessing about itself; >0 = genuine self-monitoring signal)
    # detect_d3 : probability of recognizing unknowable questions
    # false_ref : probability of wrongly refusing answerable questions
    "overconfident": {"bias": 0.25, "know": {"D1": 0.85, "D2": 0.55},
                      "introspect": 0.00, "detect_d3": 0.35, "false_ref": 0.05},
    "calibrated":    {"bias": 0.00, "know": {"D1": 0.80, "D2": 0.55},
                      "introspect": 0.30, "detect_d3": 0.90, "false_ref": 0.05},
}


class MockModel(BaseModel):
    """Deterministic simulated persona. The harness must pass the item registry
    so the mock can 'know' gold answers. It simulates two effects:
      1. confidence that is biased / miscalibrated (bias)
      2. confidence that does or does not track item-level correctness (introspect)
    """

    def __init__(self, persona: str, items, seed: int = 0):
        if persona not in _PERSONAS:
            raise ValueError(f"unknown persona {persona!r}; choose from {list(_PERSONAS)}")
        self.name = f"mock-{persona}"
        self.persona = persona
        self.cfg = _PERSONAS[persona]
        self.rng = random.Random(seed)
        self.registry = {it.item_id: it for it in items}
        self._decided: dict = {}

    # -- internals ---------------------------------------------------------
    def _decide_correct(self, item):
        if item.domain == "D3":
            return None
        if item.item_id not in self._decided:
            self._decided[item.item_id] = self.rng.random() < self.cfg["know"][item.domain]
        return self._decided[item.item_id]

    def _predict(self, item):
        base = self.cfg["know"].get(item.domain, 0.5)
        correct = self._decide_correct(item)
        # introspection signal: confidence tracks correctness, centered on the
        # persona's true competence so the signal adds no systematic ΔE bias
        signal = 0.0 if correct is None else (1.0 if correct else 0.0)
        p = base + self.cfg["bias"] + self.cfg["introspect"] * (signal - base)
        p += self.rng.gauss(0.0, 0.03)
        p = max(0.03, min(0.97, p))
        if item.domain == "D3":
            answerable = self.rng.random() > self.cfg["detect_d3"]
        else:
            answerable = self.rng.random() > self.cfg["false_ref"]
        return json.dumps({"will_answer_correctly": round(p, 3), "answerable": answerable})

    def _answer(self, item):
        if item.domain == "D3":
            if self.rng.random() < self.cfg["detect_d3"]:
                return '{"abstain": true}'
            return '{"answer": "approximately 1200 degrees Celsius"}'   # a hallucination
        if self.rng.random() < self.cfg["false_ref"]:
            return '{"abstain": true}'
        correct = self._decide_correct(item)
        if correct:
            return json.dumps({"answer": item.gold}, ensure_ascii=False)
        # wrong answers
        if item.domain == "D2":
            seq = list(item.gold)
            self.rng.shuffle(seq)
            return json.dumps({"answer": "".join(seq)}, ensure_ascii=False)
        others = [i.gold for i in self.registry.values()
                  if i.domain == "D1" and i.gold != item.gold]
        return json.dumps({"answer": self.rng.choice(others) if others else "?"})

    # -- API ---------------------------------------------------------------
    def complete(self, messages, temperature: float = 0.0, max_tokens: int = 300) -> str:
        text = messages[-1]["content"]
        m = re.search(r"\[item ([A-Za-z0-9_\-]+)\]", text)
        if not m:
            return "{}"
        item = self.registry[m.group(1)]
        if "will_answer_correctly" in text:
            return self._predict(item)
        return self._answer(item)


def make_model(args, items) -> BaseModel:
    if args.model.startswith("mock-"):
        return MockModel(args.model[5:], items, seed=args.seed)
    elif args.model == "openai":
        return OpenAICompatibleModel(args.model_name or "gpt-4o-mini",
                                     base_url=args.base_url, api_key=args.api_key)
    raise ValueError(f"unknown model spec: {args.model}")
