"""ΔE-Bench item generators.

Three domains along a knowledge spectrum:

  D1 familiar-verifiable : curated single-answer factual QA (the "memorized
                           confidence" regime — content may exist in pretraining)
  D2 novel-verifiable    : procedurally generated rule universes (ARC-style
                           anti-contamination — content is new by construction)
  D3 unknowable          : procedurally generated pseudo-facts (fabricated
                           entities / unknowable personal details)

Everything is seeded => fully reproducible. Zero third-party dependencies.
"""
from __future__ import annotations

import random
import re
from dataclasses import dataclass, field, asdict

# ---------------------------------------------------------------------------
# D2 — procedural rule universes
# ---------------------------------------------------------------------------

SYMBOLS = ["▲", "●", "■", "◆", "★", "○", "□", "◇", "△", "♠", "♣", "♥", "✦", "✧"]


@dataclass
class Item:
    item_id: str
    domain: str            # "D1" | "D2" | "D3"
    context: str           # examples / background shown before the question
    question: str
    gold: str              # canonical gold answer; "UNANSWERABLE" for D3
    answerable: bool
    aliases: tuple = ()
    meta: dict = field(default_factory=dict)


@dataclass
class Universe:
    uid: int
    difficulty: int
    symbols: list
    rule_text: list        # human-readable; hidden from the model
    fn: object             # seq(list[str]) -> list[str]

    def apply(self, seq):
        return self.fn(list(seq))


def _compose(ops):
    def fn(seq):
        cur = list(seq)
        for op in ops:
            cur = op(cur)
        return cur
    return fn


# op spec grammar:
#   ("map",   src, dst_tuple)      replace every `src` with dst_tuple elements
#   ("cond",  trig, src, dst_tuple) if trig in seq -> replace every src, else no-op
#   ("reverse",)
#   ("append", sym)

_TEMPLATES = {
    1: [
        [("map", 0, (1,))],
    ],
    2: [
        [("map", 0, (1, 2)), ("reverse",)],
        [("map", 0, (1,)), ("append", 4)],
        [("cond", 3, 0, (1, 1)), ("reverse",)],
    ],
    3: [
        [("cond", 3, 0, (1, 2)), ("map", 2, (1,)), ("reverse",)],
        [("map", 0, (1, 1)), ("reverse",), ("append", 4)],
        [("cond", 3, 0, (1, 1)), ("map", 4, (2,)), ("append", 3)],
    ],
}


def _realize(spec, syms):
    """Turn an op spec (with symbol *indices*) into (callable, desc, map_srcs, has_cond)."""
    ops, desc, map_srcs, has_cond = [], [], [], False
    a, b, c, t, p = syms[0], syms[1], syms[2], syms[3], syms[4]

    for n, s in enumerate(spec, start=1):
        kind = s[0]
        if kind == "map":
            _, i_src, i_dst = s
            src, dst = syms[i_src], tuple(syms[i] for i in i_dst)
            map_srcs.append(src)
            ops.append(lambda seq, _s=src, _d=dst: _map_one(seq, _s, _d))
            desc.append(f"R{n}: replace every {src} with {''.join(dst)}")
        elif kind == "cond":
            _, i_t, i_src, i_dst = s
            trig, src, dst = syms[i_t], syms[i_src], tuple(syms[i] for i in i_dst)
            map_srcs.append(src)
            has_cond = True
            ops.append(lambda seq, _t=trig, _s=src, _d=dst: (
                [_x for x in seq for _x in (_d if x == _s else (x,))] if _t in seq else seq))
            desc.append(f"R{n}: if the sequence contains {trig}, replace every {src} "
                        f"with {''.join(dst)}; otherwise leave the sequence unchanged")
        elif kind == "reverse":
            ops.append(lambda seq: seq[::-1])
            desc.append(f"R{n}: reverse the sequence")
        elif kind == "append":
            _, i_sym = s
            sym = syms[i_sym]
            ops.append(lambda seq, _y=sym: seq + [_y])
            desc.append(f"R{n}: append {sym} to the end of the sequence")
    return _compose(ops), desc, map_srcs, has_cond


def _map_one(seq, src, dst):
    out = []
    for x in seq:
        out.extend(dst if x == src else (x,))
    return out


def build_universe(rng: random.Random, uid: int, difficulty: int) -> Universe:
    syms = rng.sample(SYMBOLS, 6)
    spec = rng.choice(_TEMPLATES[difficulty])
    fn, desc, map_srcs, has_cond = _realize(spec, syms)
    trigger = syms[spec[0][1]] if spec[0][0] == "cond" else None

    examples = tests = None
    for _ in range(300):
        inputs = [rng.choices(syms[:5], k=rng.randint(2, 5)) for _ in range(10)]
        ex, te = inputs[:5], inputs[5:]
        ok = True
        if trigger is not None:
            n_trig = sum(trigger in s for s in ex)
            if n_trig < 2 or n_trig == 5:      # trigger must be inferable but not universal
                ok = False
        for src in map_srcs:
            if sum(src in s for s in ex) < 2:  # every mapped symbol must be seen >= 2x
                ok = False
        if ok:
            examples, tests = ex, te
            break
    if examples is None:                       # give up gracefully (astronomically unlikely)
        examples, tests = ex, te

    return Universe(uid=uid, difficulty=difficulty, symbols=syms[:5],
                    rule_text=desc, fn=fn), examples, tests


def format_examples(examples) -> str:
    lines = ["You will see examples from a NOVEL symbol-rewriting system. "
             "Infer the hidden rules, then apply them to new inputs."]
    for i, (inp, out) in enumerate(examples, start=1):
        lines.append(f"Example {i}: [{' '.join(inp)}] -> [{' '.join(out)}]")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# D1 — curated familiar-verifiable seed items
# ---------------------------------------------------------------------------

FAMILIAR_QA = [
    ("What is the capital of France?", "Paris", ("paris",)),
    ("In which year did the French Revolution begin?", "1789", ()),
    ("What is the chemical symbol for gold?", "Au", ("au",)),
    ("Who wrote the play Romeo and Juliet?", "William Shakespeare", ("shakespeare",)),
    ("What is the largest planet in the Solar System?", "Jupiter", ()),
    ("How many continents are there on Earth?", "7", ("seven",)),
    ("What is the boiling point of water at sea level, in degrees Celsius?", "100", ("100 degrees", "100c")),
    ("Who painted the Mona Lisa?", "Leonardo da Vinci", ("da vinci", "leonardo")),
    ("What is the square root of 144?", "12", ("twelve",)),
    ("Which planet is known as the Red Planet?", "Mars", ()),
    ("What is the currency of Japan?", "Yen", ("jpy",)),
    ("How many bones are there in the adult human body?", "206", ()),
    ("In which year did World War II end?", "1945", ()),
    ("What is the smallest prime number?", "2", ("two",)),
    ("Who developed the theory of general relativity?", "Albert Einstein", ("einstein",)),
    ("What is the primary language spoken in Brazil?", "Portuguese", ()),
    ("How many players from one team are on the field in a standard soccer match?", "11", ("eleven",)),
    ("What is the freezing point of water in degrees Fahrenheit?", "32", ("thirtytwo",)),
    ("Which element has atomic number 1?", "Hydrogen", ("h",)),
    ("What is the capital of Japan?", "Tokyo", ()),
    ("Who wrote the novel Pride and Prejudice?", "Jane Austen", ("austen",)),
    ("What is 15 percent of 200?", "30", ("thirty",)),
    ("In computing, what does CPU stand for?", "Central Processing Unit", ()),
    ("What gas do plants absorb from the atmosphere for photosynthesis?", "Carbon dioxide", ("co2",)),
]

# ---------------------------------------------------------------------------
# D3 — procedural pseudo-facts (unknowable)
# ---------------------------------------------------------------------------

_PRE = ["zor", "krev", "thal", "nym", "qui", "veld", "mor", "xan",
        "fens", "glor", "wren", "drav", "syl", "torv", "blem", "quis"]
_MID = ["a", "e", "i", "o", "u", "ae", "ia", "ou"]
_SUF = ["lite", "ium", "ase", "ine", "oid", "ex", "ax", "on", "yte", "ora"]

_FIRST = ["Aldric", "Miren", "Tove", "Caspar", "Ysolt", "Bram", "Odile", "Henrik", "Liesel", "Petra"]
_LAST = ["Vantrell", "Ostmark", "Quennell", "Dravenmoor", "Halloway", "Fennwick", "Solbrand", "Iverson"]


def _fake_word(rng, used):
    while True:
        w = rng.choice(_PRE) + rng.choice(_MID) + rng.choice(_SUF)
        if w not in used:
            used.add(w)
            return w


def _fake_person(rng, used):
    while True:
        p = f"{rng.choice(_FIRST)} {rng.choice(_LAST)}"
        if p not in used:
            used.add(p)
            return p


def _pseudo_fact_question(rng, used):
    """Return (question, frame). Every question here has no verifiable answer."""
    w = _fake_word(rng, used)
    frames = [
        (f"What is the melting point of {w}?", "fabricated_mineral"),
        (f"Who first discovered the mineral {w}?", "fabricated_discovery"),
        (f"In which year was the compound {w} first synthesized in a laboratory?", "fabricated_chemistry"),
        (f"Which national park is the only natural habitat of the {w} beetle?", "fabricated_species"),
    ]
    if w.endswith("ium"):
        frames.append((f"What is the standard atomic weight of {w}?", "fabricated_element"))
    q, frame = rng.choice(frames)

    person = _fake_person(rng, used)
    personal = rng.choice([
        (f"What did {person} eat for breakfast on March 12, 1997?", "unknowable_personal"),
        (f"What grade did {person} receive in their 1994 chemistry class?", "unknowable_personal"),
        (f"How many hours did {person} sleep on the night of June 3, 2001?", "unknowable_personal"),
    ])
    if rng.random() < 0.6:
        return q, frame
    return personal


# ---------------------------------------------------------------------------
# Assembly
# ---------------------------------------------------------------------------

def build_items(rng: random.Random, n_universes: int = 12,
                n_familiar: int = 24, n_pseudo: int = 36):
    """Build the full item set. Returns (items, universes)."""
    items, universes = [], []

    # D1
    for i, (q, gold, aliases) in enumerate(FAMILIAR_QA[:n_familiar]):
        items.append(Item(item_id=f"D1-{i:03d}", domain="D1", context="",
                          question=q, gold=gold, answerable=True,
                          aliases=tuple(aliases), meta={"source": "curated_seed"}))

    # D2 — balanced difficulty 1/2/3
    for i in range(n_universes):
        difficulty = 1 + (i % 3)
        uni, ex, te = build_universe(rng, i, difficulty)
        universes.append(uni)
        ctx = format_examples([(s, uni.apply(s)) for s in ex])
        for j, inp in enumerate(te):
            gold = "".join(uni.apply(inp))
            items.append(Item(
                item_id=f"D2-u{i:02d}-{j:02d}", domain="D2", context=ctx,
                question=f"Apply the same hidden rules. Input: [{' '.join(inp)}]\n"
                         f"What is the output sequence? (output the sequence only)",
                gold=gold, answerable=True,
                meta={"universe": i, "difficulty": difficulty,
                      "hidden_rules": uni.rule_text, "input": "".join(inp)}))

    # D3
    used = set()
    for i in range(n_pseudo):
        q, frame = _pseudo_fact_question(rng, used)
        items.append(Item(item_id=f"D3-{i:03d}", domain="D3", context="",
                          question=q, gold="UNANSWERABLE", answerable=False,
                          meta={"frame": frame}))

    return items, universes


def items_to_dicts(items):
    return [asdict(it) for it in items]
