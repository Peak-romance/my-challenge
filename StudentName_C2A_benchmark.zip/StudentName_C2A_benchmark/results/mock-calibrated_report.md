# ΔE-Bench run report — `mock-calibrated`

| metric | value | reads as |
|---|---|---|
| accuracy (all items) | 0.65 | incl. D3 abstention scoring |
| accuracy (attempted, D1+D2) | 0.5949 | raw competence |
| **ΔE overall** | 0.0033 | CI95 [-0.0775, 0.0843]; + overconfident / − underconfident |
| ECE | 0.2607 | calibration alignment (lower = better) |
| **AUC** | 0.9382 | discrimination (0.5 = coin flip) |
| ΔE(D1)−ΔE(D2) | 0.0559 | 'memorized-confidence gap': how much more overconfident on familiar content |
| d′ (abstention) | 2.5923 | 0 = no signal (or always-abstain gaming) |
| D3 refusal rate (TPR) | 0.8611 | refuses unknowable |
| D3 boundary-flag accuracy | 0.8333 | predicts 'unanswerable' in the PREDICT turn |
| false refusal rate (FPR) | 0.0595 | wrongly refuses answerable |
| **Metacognitive Gain** | 0.4051 | acc(selected@τ=0.7) 1.0 − acc(attempted) 0.5949 |
| ΔE split-half instability | 0.0711 | reliability smoke-check (lower = stabler) |

## Per-domain

| domain | n | attempted | accuracy | ΔE |
|---|---|---|---|---|
| D1 | 24 | 23 | 0.7391 | 0.0429 |
| D2 | 60 | 56 | 0.5357 | -0.013 |
| D3 | (unknowable items; see refusal TPR / boundary flag / d′ above) | | | |

> Mock-model runs validate the measurement pipeline only — they are simulated personas, not evidence about any real LLM.
