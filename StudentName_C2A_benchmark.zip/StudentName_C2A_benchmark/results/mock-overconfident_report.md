# ΔE-Bench run report — `mock-overconfident`

| metric | value | reads as |
|---|---|---|
| accuracy (all items) | 0.575 | incl. D3 abstention scoring |
| accuracy (attempted, D1+D2) | 0.7342 | raw competence |
| **ΔE overall** | 0.1173 | CI95 [0.0255, 0.2183]; + overconfident / − underconfident |
| ECE | 0.1173 | calibration alignment (lower = better) |
| **AUC** | 0.5558 | discrimination (0.5 = coin flip) |
| ΔE(D1)−ΔE(D2) | -0.0851 | 'memorized-confidence gap': how much more overconfident on familiar content |
| d′ (abstention) | 1.02 | 0 = no signal (or always-abstain gaming) |
| D3 refusal rate (TPR) | 0.3056 | refuses unknowable |
| D3 boundary-flag accuracy | 0.2778 | predicts 'unanswerable' in the PREDICT turn |
| false refusal rate (FPR) | 0.0595 | wrongly refuses answerable |
| **Metacognitive Gain** | 0.0 | acc(selected@τ=0.7) 0.7342 − acc(attempted) 0.7342 |
| ΔE split-half instability | 0.0909 | reliability smoke-check (lower = stabler) |

## Per-domain

| domain | n | attempted | accuracy | ΔE |
|---|---|---|---|---|
| D1 | 24 | 23 | 0.913 | 0.057 |
| D2 | 60 | 56 | 0.6607 | 0.1421 |
| D3 | (unknowable items; see refusal TPR / boundary flag / d′ above) | | | |

> Mock-model runs validate the measurement pipeline only — they are simulated personas, not evidence about any real LLM.
