# ΔE-Bench — Predictive Metacognition Benchmark (Prototype)

> **测量的问题：模型在作答之前，能否预测自己"会不会"？**
> Track 2 — Metacognition ｜ C2A 提案的原型实现 ｜ 版本 0.1.0

ΔE-Bench 实现了提案《StudentName_C2A_proposal_v2.md》中的 **PAV 协议（Predict–Answer–Verify）**：
每道题先让模型**预测**自己答对的概率与题目是否可答（KSTAR 的 R̂_E），再**作答**（或拒答），最后**客观校验**（R）。
预测与作答两轮独立，互不泄漏，杜绝锚定。

## 三个知识谱系域

| 域 | 内容 | 测什么 | 数量（默认） |
|---|---|---|---|
| **D1 熟悉可验证** | 24 道策展事实题（单答案、可精确匹配） | "记忆型自信" | 24 |
| **D2 新颖可验证** | 程序化生成的符号规则宇宙（1–3 条规则，先给 5 示例再作答） | "内省型自信"——内容保证不在任何训练数据中 | 60（12 宇宙 × 5 题） |
| **D3 不可知** | 程序化伪事实（虚构术语 / 不可知的个人细节） | 知识边界识别：正确行为是拒答 | 36 |

D2/D3 全部由种子生成：**任何人可用同一生成器再造全新等价题集**——污染在结构上不可能。

## 指标

| 指标 | 定义 | 防什么 |
|---|---|---|
| **ΔE** | mean(预测 − 实际)，分域报告，带符号（+ 过度自信 / − 不足） | — |
| **ECE** | 十分箱校准误差 | — |
| **AUC** | 预测区分对/错题的判别力（Mann–Whitney） | 恒 0.5 置信策略 |
| **d′** | 拒答行为的信号检测量（D3=信号，D1/D2 误拒=虚报） | 恒拒答策略（d′=0） |
| **MG** | 元认知收益：按预测选择性作答的准确率 − 强制作答准确率 | 自知识不兑现为决策 |
| 签名指标 | ΔE(D1)−ΔE(D2) | 量化"记忆型自信"占比 |

**核心设计原则：校准（ECE）与判别（AUC）必须分开报告。** 见下方模拟结果——单一 ECE 会把两个模型排反。

## 快速开始

```bash
# 纯标准库实现，无第三方依赖；Python >= 3.10

# 0) 评分函数自检（断言包含"恒0.5可骗ECE但骗不过AUC""恒拒答d'=0"）
python run_eval.py --selftest

# 1) 离线管线验证：两个模拟人格对比
python run_eval.py --model mock-overconfident
python run_eval.py --model mock-calibrated

# 2) 真实模型：任意 OpenAI 兼容端点（OpenAI / DeepSeek / vLLM / Ollama …）
export DELTAE_API_KEY=sk-...          # Windows: set DELTAE_API_KEY=sk-...
python run_eval.py --model openai --model-name gpt-4o-mini \
    --base-url https://api.openai.com/v1

# 3) 固定种子再生成数据集
python run_eval.py --model mock-calibrated --dump-items data/sample_items.json
```

输出：`results/<model>_metrics.json`（机器可读）+ `results/<model>_report.md`（人类可读）。

## 模拟模型验证结果（seed=20261004，120 题）

| 指标 | mock-overconfident | mock-calibrated | 解读 |
|---|---|---|---|
| ΔE overall | **+0.117** | **+0.003** | 过度自信 vs 几乎完美校准 |
| AUC | 0.556 | **0.938** | 前者对"哪题会对"毫无分辨力 |
| **ECE** | **0.117** | 0.261 | ⚠️ 单看 ECE 会把两者排反！ |
| d′（拒答） | 1.02 | **2.59** | 边界识别能力差距 |
| MG（τ=0.7） | ≈0 | **0.405** | 元认知是否兑现为决策收益 |

**为什么校准型人格的 ECE 反而更高？** 它的置信度呈双峰分布（对题≈0.86、错题≈0.56——强烈的内省信号），分箱后每箱的绝对数值与箱内正确率有系统性偏移。这正是提案强调"**ECE 与 AUC 必须分开报告**"的活例证：判别力极强（AUC 0.94）的模型可以被单一 ECE 指标冤枉。ΔE / AUC / d′ / MG 组合才能完整刻画元认知。

> ⚠️ 模拟模型仅验证**测量管线**与**指标行为**，不构成对任何真实 LLM 的证据。

## 目录结构

```
run_eval.py                 CLI 入口（--selftest / mock / openai）
deltae_bench/
  generator.py              D1 策展题 + D2 规则宇宙生成器 + D3 伪事实生成器
  protocol.py               PAV 协议提示词与 JSON 解析
  models.py                 OpenAI 兼容适配器 + 双人格 MockModel
  scoring.py                ΔE / ECE / AUC / d′ / MG / bootstrap CI / 自检
data/sample_items.json      预生成的 120 道样题（seed=20261004）
results/                    模拟运行产物（metrics.json + report.md）
```

## 评分规格（对接 Kaggle Community Benchmarks）

- **判分**：D1/D2 = 规范化精确匹配（含别名表；LLM 评委仅作别名兜底且与被测模型不同源）；D3 = 拒答记对、作答记错。
- **提交内容**：模型在 120 题上的 PAV 原始输出（预测 JSON + 作答 JSON）；
- **排行榜**：以 ΔE / AUC / d′ / MG 四指标综合排名，任何单一指标不构成名次依据（防 Goodhart）。

## 已知局限（与提案一致）

1. D2 规则归纳存在多解歧义（与 ARC 同源），通过约束规则原语（4 类）缓解；
2. D1 为静态策展题，仅作"记忆型自信"对照域，不作主指标域；
3. 人类基线（3 组 × 30 人）为 C9 阶段任务，本原型不含；
4. MockModel 的"内省信号"是参数化的，真实模型的信号形态需实证测量。

## 归属

设计出处、借鉴来源与取舍分析见上层目录《StudentName_C2A_拿来说明.md》（Kadavath P(IK)、SimpleQA 三态判分、SelfAware 不可答题、ARC 去污染、Nelson & Narens 监控时间点）。
