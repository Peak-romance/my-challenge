#!/usr/bin/env python3
"""ΔE-Bench runner.

Examples
--------
# 0) self-test of all scoring functions (no network)
python run_eval.py --selftest

# 1) offline pipeline validation with two simulated personas
python run_eval.py --model mock-overconfident
python run_eval.py --model mock-calibrated

# 2) real model via any OpenAI-compatible endpoint
export DELTAE_API_KEY=sk-...
python run_eval.py --model openai --model-name gpt-4o-mini \
    [--base-url https://api.openai.com/v1]

# 3) regenerate the sample dataset
python run_eval.py --model mock-calibrated --dump-items data/sample_items.json
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from deltae_bench.generator import build_items, items_to_dicts
from deltae_bench.models import make_model
from deltae_bench.protocol import (SYSTEM_PROMPT, answer_prompt, parse_answer,
                                   parse_prediction, predict_prompt)
from deltae_bench.scoring import evaluate_run, exact_match, selftest


def run(items, model, mg_threshold: float = 0.7, verbose: bool = False):
    records = []
    for item in items:
        # Turn 1 — PREDICT (before any answering)
        ptext = model.complete([{"role": "system", "content": SYSTEM_PROMPT},
                                {"role": "user", "content": predict_prompt(item)}])
        pred, aflag = parse_prediction(ptext)

        # Turn 2 — ANSWER
        atext = model.complete([{"role": "system", "content": SYSTEM_PROMPT},
                                {"role": "user", "content": answer_prompt(item)}])
        abstain, answer = parse_answer(atext)

        # Verify — objective scoring
        if item.domain == "D3":
            attempted = not abstain
            correct = abstain            # correct behavior on unknowable items is abstention
        else:
            attempted = not abstain
            correct = (not abstain) and exact_match(answer, item.gold, item.aliases)

        rec = {"item_id": item.item_id, "domain": item.domain, "pred": pred,
               "answerable_flag": aflag, "abstain": abstain, "answer": answer,
               "attempted": attempted, "correct": correct,
               "gold": item.gold if verbose else None}
        records.append(rec)
        if verbose:
            mark = "OK " if correct else "MISS"
            print(f"[{mark}] {item.item_id:<12} pred={pred:.2f} "
                  f"abstain={abstain} ans={answer[:40]!r}")
    return records


def write_report(model_name: str, metrics: dict, path: str) -> None:
    L = []
    L.append(f"# ΔE-Bench run report — `{model_name}`\n")
    L.append("| metric | value | reads as |")
    L.append("|---|---|---|")
    m = metrics
    L.append(f"| accuracy (all items) | {m['accuracy_all']} | incl. D3 abstention scoring |")
    L.append(f"| accuracy (attempted, D1+D2) | {m['accuracy_attempted']} | raw competence |")
    L.append(f"| **ΔE overall** | {m['delta_e_overall']} | CI95 {m['delta_e_CI95']}; "
             f"+ overconfident / − underconfident |")
    L.append(f"| ECE | {m['ece']} | calibration alignment (lower = better) |")
    L.append(f"| **AUC** | {m['auc']} | discrimination (0.5 = coin flip) |")
    L.append(f"| ΔE(D1)−ΔE(D2) | {m['signature_memorized_confidence_gap']} | "
             f"'memorized-confidence gap': how much more overconfident on familiar content |")
    L.append(f"| d′ (abstention) | {m['d_prime_abstention']} | 0 = no signal (or always-abstain gaming) |")
    L.append(f"| D3 refusal rate (TPR) | {m['d3_refusal_rate_TPR']} | refuses unknowable |")
    L.append(f"| D3 boundary-flag accuracy | {m['d3_boundary_flag_accuracy']} | "
             f"predicts 'unanswerable' in the PREDICT turn |")
    L.append(f"| false refusal rate (FPR) | {m['false_refusal_rate_FPR']} | wrongly refuses answerable |")
    mg = m["metacognitive_gain"]
    L.append(f"| **Metacognitive Gain** | {mg['gain']} | "
             f"acc(selected@τ={mg['threshold']}) {mg['selected_accuracy']} − "
             f"acc(attempted) {mg['attempted_accuracy']} |")
    L.append(f"| ΔE split-half instability | {m['split_half_de_instability']} | "
             f"reliability smoke-check (lower = stabler) |")
    L.append("\n## Per-domain\n")
    L.append("| domain | n | attempted | accuracy | ΔE |")
    L.append("|---|---|---|---|---|")
    for dom in ("D1", "D2"):
        pd_ = m["per_domain"][dom]
        L.append(f"| {dom} | {pd_['n']} | {pd_['attempted']} | {pd_['accuracy']} | {pd_['delta_e']} |")
    L.append("| D3 | (unknowable items; see refusal TPR / boundary flag / d′ above) | | | |")
    L.append("\n> Mock-model runs validate the measurement pipeline only — they are "
             "simulated personas, not evidence about any real LLM.\n")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def main() -> None:
    ap = argparse.ArgumentParser(description="ΔE-Bench: predictive metacognition benchmark")
    ap.add_argument("--model", default="mock-calibrated",
                    help="mock-overconfident | mock-calibrated | openai")
    ap.add_argument("--model-name", default=None, help="model id for --model openai")
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--api-key", default=None)
    ap.add_argument("--seed", type=int, default=20261004)
    ap.add_argument("--n-universes", type=int, default=12)
    ap.add_argument("--n-familiar", type=int, default=24)
    ap.add_argument("--n-pseudo", type=int, default=36)
    ap.add_argument("--mg-threshold", type=float, default=0.7)
    ap.add_argument("--dump-items", default=None, help="write item JSON here")
    ap.add_argument("--out-dir", default="results")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    try:  # Windows console + unicode symbols
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    if args.selftest:
        selftest()
        return

    rng = random.Random(args.seed)
    items, universes = build_items(rng, args.n_universes, args.n_familiar, args.n_pseudo)
    print(f"[items] D1={sum(1 for i in items if i.domain=='D1')} "
          f"D2={sum(1 for i in items if i.domain=='D2')} "
          f"D3={sum(1 for i in items if i.domain=='D3')}  (seed={args.seed})")

    if args.dump_items:
        os.makedirs(os.path.dirname(args.dump_items) or ".", exist_ok=True)
        with open(args.dump_items, "w", encoding="utf-8") as f:
            json.dump(items_to_dicts(items), f, ensure_ascii=False, indent=1)
        print(f"[items] dumped -> {args.dump_items}")

    model = make_model(args, items)
    print(f"[run ] model = {model.name}")
    records = run(items, model, args.mg_threshold, args.verbose)

    metrics = evaluate_run(records, args.mg_threshold)
    metrics["model"] = model.name
    metrics["seed"] = args.seed

    os.makedirs(args.out_dir, exist_ok=True)
    tag = model.name.replace("/", "_")
    mpath = os.path.join(args.out_dir, f"{tag}_metrics.json")
    rpath = os.path.join(args.out_dir, f"{tag}_report.md")
    with open(mpath, "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=1)
    write_report(model.name, metrics, rpath)

    print(json.dumps({k: metrics[k] for k in
                      ("delta_e_overall", "ece", "auc", "d_prime_abstention")}, indent=1))
    print(f"[out ] {mpath}\n[out ] {rpath}")


if __name__ == "__main__":
    main()
